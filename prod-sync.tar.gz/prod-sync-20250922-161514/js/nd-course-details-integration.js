/**
 * COURSE DETAILS PAGE INTEGRATION
 * Connects detail_courses.html to the nd_courses API endpoint
 * Handles dynamic content population and preview mode
 */

(function() {
    'use strict';

    // API Configuration
    const API_BASE = window.location.hostname === 'localhost'
        ? 'http://localhost:3000'
        : 'https://aistudio555jamstack-production.up.railway.app';

    // Static course images mapping by category
    const COURSE_IMAGES = {
        'Web Development': 'https://images.unsplash.com/photo-1547658719-da2b51169166?w=800&q=80',
        'App Development': 'https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?w=800&q=80',
        'Machine Learning': 'https://images.unsplash.com/photo-1677442136019-21780ecad995?w=800&q=80',
        'Data Science': 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&q=80',
        'Programming': 'https://images.unsplash.com/photo-1517180102446-f3ece451e9d8?w=800&q=80',
        'AI & ML': 'https://images.unsplash.com/photo-1677442136019-21780ecad995?w=800&q=80',
        'Cloud Computing': 'https://images.unsplash.com/photo-1544197150-b99a580bb7a8?w=800&q=80',
        'Mobile Dev': 'https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?w=800&q=80',
        'DevOps': 'https://images.unsplash.com/photo-1667372393119-3d4c48d07fc9?w=800&q=80',
        'default': 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=800&q=80'
    };

    // Get static image for course based on category
    function getStaticCourseImage(category) {
        return COURSE_IMAGES[category] || COURSE_IMAGES['default'];
    }

    // Extract URL parameters
    function getUrlParams() {
        const params = new URLSearchParams(window.location.search);
        return {
            id: params.get('id'),
            preview: params.get('preview') === 'true'
        };
    }

    // Fetch course data from API
    async function fetchCourseData(courseId, preview = false) {
        try {
            const locale = localStorage.getItem('preferred_locale') || 'en';
            const url = `${API_BASE}/api/nd/courses/${courseId}?locale=${locale}${preview ? '&preview=true' : ''}`;
            console.log('🔍 Fetching course:', url);

            const response = await fetch(url);
            if (!response.ok) {
                throw new Error(`Failed to fetch course: ${response.status}`);
            }

            const data = await response.json();
            console.log('✅ Course data received:', data);

            // Handle wrapped API response format
            if (data.success && data.data) {
                return data.data;
            }
            return data;
        } catch (error) {
            console.error('❌ Error fetching course:', error);
            return null;
        }
    }

    // Generate star rating HTML
    function generateStarRating(rating) {
        const fullStars = Math.floor(rating);
        let starsHtml = '';

        for (let i = 0; i < 5; i++) {
            const opacity = i < fullStars ? '1' : '0.3';
            starsHtml += `<img src="images/Featured-Courses-Rating-Icon.svg"
                             alt="Star"
                             style="opacity: ${opacity}; width: 16px; height: 16px; display: inline-block; margin-right: 2px;">`;
        }

        return starsHtml;
    }

    // Format price display
    function formatPrice(price, oldPrice) {
        if (!price || price === 0) {
            return '<span>Free</span>';
        }

        let html = `<span>$${price}</span>`;
        if (oldPrice && oldPrice > price) {
            html = `<span style="text-decoration: line-through; opacity: 0.7; margin-right: 8px;">$${oldPrice}</span>${html}`;
        }
        return html;
    }

    // Populate course details
    function populateCourseDetails(course) {
        console.log('📝 Populating course details...');

        // Course Name and Description - Webflow Structure
        const courseName = document.querySelector('.course-details-name');
        if (courseName) {
            courseName.textContent = course.title || '';
            console.log('✅ Set course name to:', course.title);
        }

        const courseDescriptionText = document.querySelector('.course-details-description-text');
        if (courseDescriptionText) {
            courseDescriptionText.textContent = course.short_description || course.description || '';
            console.log('✅ Set course description to:', course.short_description || course.description);
        }

        // Author Information - Webflow Structure
        const authorName = document.querySelector('.course-details-author-name');
        if (authorName) {
            authorName.textContent = course.instructor || 'Expert Instructor';
        }

        const authorBio = document.querySelector('.course-details-author-bio');
        if (authorBio) {
            authorBio.textContent = course.instructor_bio || 'Experienced professional with years of industry expertise and a passion for teaching.';
        }

        const authorImage = document.querySelector('.courses-single-author-image');
        if (authorImage) {
            authorImage.src = course.instructor_image || 'images/default-instructor.jpg';
            authorImage.alt = course.instructor || 'Instructor';
        }

        // Short Categories - Webflow Structure
        const shortCategoriesText = document.querySelector('.course-details-short-categories-text');
        if (shortCategoriesText) {
            shortCategoriesText.textContent = course.category || 'General';
        }

        // Show course details content with opacity animation
        const courseDetailsContent = document.querySelector('.course-details-content');
        if (courseDetailsContent) {
            courseDetailsContent.style.opacity = '1';
            courseDetailsContent.classList.add('visible');
            console.log('✅ Course details content made visible');
        }

        // Breadcrumb
        const breadcrumb = document.querySelector('.course-breadcrumb-title');
        if (breadcrumb) {
            breadcrumb.textContent = course.title || '';
        }

        // Main Content Area - Custom Structure
        const fullDescription = document.querySelector('.course-full-description');
        if (fullDescription) {
            fullDescription.textContent = course.description || '';
        }

        const curriculumDescription = document.querySelector('.course-curriculum-description');
        if (curriculumDescription) {
            curriculumDescription.textContent = `This ${course.lessons_count || 0}-lesson course covers all aspects of ${course.title || 'the subject'}.`;
        }

        // Rating
        const ratingContainer = document.querySelector('.course-rating-stars');
        if (ratingContainer && course.rating) {
            ratingContainer.innerHTML = generateStarRating(course.rating);
        }

        const ratingText = document.querySelector('.course-rating-text');
        if (ratingText) {
            ratingText.textContent = `${course.rating || 5.0} (${course.reviews_count || 0} reviews)`;
        }

        // Course meta information
        const instructorElement = document.querySelector('.course-instructor');
        if (instructorElement) instructorElement.textContent = course.instructor || 'Expert Instructor';

        const durationElement = document.querySelector('.course-duration');
        if (durationElement) durationElement.textContent = course.duration || '8 weeks';

        // Sidebar price - Webflow Structure
        const currentPriceElement = document.querySelector('.courses-single-current-price');
        if (currentPriceElement) currentPriceElement.textContent = `$${course.price || '99.99'}`;

        const oldPriceElement = document.querySelector('.courses-single-old-price');
        if (oldPriceElement && course.old_price) {
            oldPriceElement.textContent = `$${course.old_price}`;
            oldPriceElement.style.textDecoration = 'line-through';
        }

        const lessonsCountElement = document.querySelector('.course-lessons-count');
        if (lessonsCountElement) lessonsCountElement.textContent = course.lessons_count || '0';

        const studentsCountElement = document.querySelector('.course-students-count');
        if (studentsCountElement) studentsCountElement.textContent = course.students_count || '0';

        const levelElement = document.querySelector('.course-level');
        if (levelElement) levelElement.textContent = course.level || 'All Levels';

        // Category tag - Webflow Structure
        const categoryTag = document.querySelector('.courses-single-category-tag');
        if (categoryTag) categoryTag.textContent = course.category || 'General';

        // Instructor info (sidebar)
        const instructorNameElement = document.querySelector('.instructor-name');
        if (instructorNameElement) instructorNameElement.textContent = course.instructor || 'Expert Instructor';

        const instructorImageElement = document.querySelector('.instructor-image');
        if (instructorImageElement) {
            instructorImageElement.src = course.instructor_image || 'images/default-instructor.jpg';
            instructorImageElement.alt = course.instructor || 'Instructor';
        }

        const instructorBioElement = document.querySelector('.instructor-bio');
        if (instructorBioElement) {
            instructorBioElement.textContent = course.instructor_bio || 'Experienced professional with years of industry expertise and a passion for teaching.';
        }

        // Course video/image thumbnail - Webflow Structure
        const courseThumbnail = document.querySelector('.courses-single-video-thumbnail');
        if (courseThumbnail) {
            const thumbnailUrl = course.image || getStaticCourseImage(course.category);
            courseThumbnail.src = thumbnailUrl;
            courseThumbnail.alt = course.title || 'Course';
        }

        // Course Objectives (What You'll Learn)
        if (course.what_you_learn && course.what_you_learn.length > 0) {
            const objectivesContainer = document.querySelector('.course-objectives-list');
            if (objectivesContainer) {
                const objectives = Array.isArray(course.what_you_learn) ? course.what_you_learn : course.what_you_learn.split(',').map(obj => obj.trim());
                objectivesContainer.innerHTML = objectives.map(obj =>
                    `<div class="course-objective-item">
                        <span class="checkmark">✓</span>
                        <span>${obj}</span>
                    </div>`
                ).join('');
            }
        }

        // Course Requirements
        if (course.requirements && course.requirements.length > 0) {
            const requirementsContainer = document.querySelector('.course-requirements-list');
            if (requirementsContainer) {
                const requirements = Array.isArray(course.requirements) ? course.requirements : course.requirements.split(',').map(req => req.trim());
                requirementsContainer.innerHTML = requirements.map(req =>
                    `<div class="course-requirement-item">${req}</div>`
                ).join('');
            }
        }

        // Lessons/Curriculum
        if (course.syllabus && course.syllabus.length > 0) {
            const lessonsContainer = document.querySelector('.course-lessons-container');
            if (lessonsContainer) {
                try {
                    const lessons = typeof course.lessons === 'string' ? JSON.parse(course.lessons) : course.lessons;
                    if (Array.isArray(lessons)) {
                        lessonsContainer.innerHTML = lessons.map((lesson, index) =>
                            `<div class="courses-single-lesson-item">
                                <div class="courses-single-lesson-number">${index + 1}</div>
                                <div class="courses-single-lesson-content">
                                    <div class="courses-single-lesson-title">${lesson.title || lesson}</div>
                                    ${lesson.duration ? `<div class="courses-single-lesson-duration">${lesson.duration}</div>` : ''}
                                </div>
                            </div>`
                        ).join('');
                    }
                } catch (e) {
                    console.warn('Could not parse lessons:', e);
                    // Fallback: treat as comma-separated string
                    if (typeof course.lessons === 'string') {
                        const lessonsList = course.lessons.split(',').map(l => l.trim());
                        lessonsContainer.innerHTML = lessonsList.map((lesson, index) =>
                            `<div class="courses-single-lesson-item">
                                <div class="courses-single-lesson-number">${index + 1}</div>
                                <div class="courses-single-lesson-title">${lesson}</div>
                            </div>`
                        ).join('');
                    }
                }
            }
        }

        // Features - Webflow Structure
        if (course.features && course.features.length > 0) {
            const featuresContainer = document.querySelector('.courses-single-features');
            if (featuresContainer) {
                // Handle both array and string formats
                const features = Array.isArray(course.features)
                    ? course.features
                    : course.features.split(',').map(f => f.trim());

                featuresContainer.innerHTML = features.map(feature =>
                    `<div class="courses-single-feature-item">
                        <div class="courses-single-feature-icon"></div>
                        <div class="courses-single-feature-text">${feature}</div>
                    </div>`
                ).join('');
            }
        } else {
            // Default features if none provided
            const featuresContainer = document.querySelector('.courses-single-features');
            if (featuresContainer) {
                const defaultFeatures = [
                    'Lifetime access',
                    'Certificate of completion',
                    'Expert instructor support',
                    'Mobile learning'
                ];
                featuresContainer.innerHTML = defaultFeatures.map(feature =>
                    `<div class="courses-single-feature-item">
                        <div class="courses-single-feature-icon"></div>
                        <div class="courses-single-feature-text">${feature}</div>
                    </div>`
                ).join('');
            }
        }

        // Students Enrolled
        const studentsElement = document.querySelector('.courses-single-students-count');
        if (studentsElement) {
            studentsElement.textContent = `${course.students_enrolled || 0} students enrolled`;
        }

        // Remove empty state placeholders
        const emptyStates = document.querySelectorAll('.w-dyn-bind-empty, .w-dyn-empty');
        emptyStates.forEach(el => {
            el.style.display = 'none';
        });

        // Show content areas
        const contentAreas = document.querySelectorAll('.w-dyn-hide-empty');
        console.log('🔍 Found content areas to show:', contentAreas.length);
        contentAreas.forEach(el => {
            el.style.display = 'block';
            console.log('✅ Showing content area:', el.className);
        });

        // Also ensure main sections are visible
        const mainSections = document.querySelectorAll('.course-overview-section, .course-objectives-section, .course-curriculum-section, .course-requirements-section');
        console.log('🔍 Found main sections:', mainSections.length);
        mainSections.forEach(section => {
            section.style.display = 'block';
            section.style.opacity = '1';
            section.style.visibility = 'visible';
            console.log('✅ Ensuring section is visible:', section.className);
        });

        // Course guarantee
        const guaranteeTextElement = document.querySelector('.course-guarantee-text');
        if (guaranteeTextElement) {
            guaranteeTextElement.textContent = '30-day money-back guarantee';
        }

        // CTA section
        const ctaTitleElement = document.querySelector('.course-cta-title');
        if (ctaTitleElement) {
            ctaTitleElement.textContent = `Ready to start ${course.title}?`;
        }

        const ctaDescriptionElement = document.querySelector('.course-cta-description');
        if (ctaDescriptionElement) {
            ctaDescriptionElement.textContent = `Join thousands of students who have already mastered ${course.category} with our comprehensive course.`;
        }

        // Ensure all content is visible in Webflow structure
        // (courseDetailsContent already declared above)

        // Remove any hiding classes and ensure visibility
        const allElements = document.querySelectorAll('.courses-single *');
        allElements.forEach(el => {
            if (el.classList.contains('w-dyn-hide-empty') || el.style.opacity === '0' || el.style.display === 'none') {
                el.style.display = 'block';
                el.style.opacity = '1';
                el.style.visibility = 'visible';
                el.classList.remove('w-dyn-hide-empty');
            }
        });

        console.log('✅ Custom shared course details component populated successfully');
    }

    // Get category color
    function getCategoryColor(category) {
        if (!category) return '#667eea';

        const cat = category.toLowerCase();
        if (cat.includes('web')) return '#667eea';
        if (cat.includes('app') || cat.includes('mobile')) return '#f093fb';
        if (cat.includes('machine') || cat.includes('ml') || cat.includes('ai')) return '#4facfe';
        if (cat.includes('cloud')) return '#43e97b';
        if (cat.includes('data')) return '#ff6b6b';
        if (cat.includes('design')) return '#feca57';

        return '#667eea';
    }

    // Show error message
    function showError(message) {
        console.error('❌ Error:', message);

        // Find or create error container
        let errorContainer = document.querySelector('.course-error-message');
        if (!errorContainer) {
            errorContainer = document.createElement('div');
            errorContainer.className = 'course-error-message';
            errorContainer.style.cssText = `
                position: fixed;
                top: 20px;
                left: 50%;
                transform: translateX(-50%);
                background: #ff4444;
                color: white;
                padding: 15px 30px;
                border-radius: 8px;
                font-size: 16px;
                z-index: 9999;
                box-shadow: 0 4px 20px rgba(255,68,68,0.3);
            `;
            document.body.appendChild(errorContainer);
        }

        errorContainer.textContent = message;
        errorContainer.style.display = 'block';

        // Hide after 5 seconds
        setTimeout(() => {
            errorContainer.style.display = 'none';
        }, 5000);
    }

    // Fetch page UI translations
    async function fetchPageTranslations(locale) {
        try {
            const url = `${API_BASE}/api/nd/course-details-page?locale=${locale}`;
            console.log('🔍 Fetching page translations:', url);

            const response = await fetch(url);
            if (!response.ok) {
                console.warn('Failed to fetch page translations');
                return null;
            }

            const data = await response.json();
            if (data.success && data.data) {
                return data.data;
            }
            return data;
        } catch (error) {
            console.error('Error fetching page translations:', error);
            return null;
        }
    }

    // Apply page translations
    function applyPageTranslations(translations) {
        if (!translations) return;

        console.log('📝 Applying page translations...');

        // Apply translations to elements with data-i18n attributes
        document.querySelectorAll('[data-i18n]').forEach(element => {
            const key = element.getAttribute('data-i18n');
            const keys = key.split('.');

            let value = translations;
            for (const k of keys) {
                if (value && value[k]) {
                    if (value[k].content && typeof value[k].content === 'object') {
                        value = value[k].content;
                    } else {
                        value = value[k];
                    }
                } else {
                    break;
                }
            }

            if (value && typeof value === 'string') {
                element.textContent = value;
            } else if (value && value.content && typeof value.content === 'string') {
                element.textContent = value.content;
            } else if (value && typeof value === 'object' && keys[keys.length - 1] in value) {
                element.textContent = value[keys[keys.length - 1]];
            }
        });

        // Update specific UI elements
        if (translations.ui_elements && translations.ui_elements.content) {
            const ui = translations.ui_elements.content;

            // Update buttons
            if (ui.buttons) {
                const enrollButtons = document.querySelectorAll('.enroll-button, .primary-button');
                enrollButtons.forEach(btn => {
                    const textElements = btn.querySelectorAll('.primary-button-text-block');
                    if (textElements.length > 0 && ui.buttons.enroll_now) {
                        textElements.forEach(el => el.textContent = ui.buttons.enroll_now);
                    }
                });
            }

            // Update labels
            if (ui.labels) {
                const priceLabel = document.querySelector('.price-label');
                if (priceLabel && ui.labels.price) priceLabel.textContent = ui.labels.price;

                const levelLabel = document.querySelector('.level-label');
                if (levelLabel && ui.labels.level) levelLabel.textContent = ui.labels.level;

                const studentsLabel = document.querySelector('.students-label');
                if (studentsLabel && ui.labels.students) studentsLabel.textContent = ui.labels.students;
            }
        }
    }

    // Initialize on page load
    async function init() {
        console.log('🚀 Initializing Course Details Page...');

        // Get current locale
        const locale = localStorage.getItem('preferred_locale') || 'en';

        // Fetch and apply page translations
        const translations = await fetchPageTranslations(locale);
        if (translations) {
            applyPageTranslations(translations);
        }

        const params = getUrlParams();

        if (!params.id) {
            showError('No course ID provided in URL');
            return;
        }

        // Show loading state
        const loadingIndicator = document.createElement('div');
        loadingIndicator.className = 'course-loading';
        loadingIndicator.style.cssText = `
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            font-size: 18px;
            color: #667eea;
            z-index: 9999;
        `;
        loadingIndicator.textContent = 'Loading course details...';
        document.body.appendChild(loadingIndicator);

        // Fetch and populate course data
        const courseData = await fetchCourseData(params.id, params.preview);

        // Remove loading indicator
        loadingIndicator.remove();

        if (courseData) {
            populateCourseDetails(courseData);

            // Update page title
            document.title = `${courseData.title || 'Course'} - AI Studio`;

            // Add enrollment button handlers
            const enrollButtons = document.querySelectorAll('.courses-single-enroll-button, .primary-button');
            enrollButtons.forEach(btn => {
                btn.addEventListener('click', (e) => {
                    e.preventDefault();
                    // Open contact modal or navigate to enrollment
                    console.log('Enrollment clicked for course:', courseData.id);
                    // You can trigger the contact form modal here
                    if (window.openContactModal) {
                        window.openContactModal();
                    }
                });
            });
        } else {
            showError('Failed to load course details. Please try again.');
        }
    }

    // Start initialization when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    // Expose functions globally for debugging
    window.ndCourseDetails = {
        fetchCourseData,
        populateCourseDetails,
        init
    };

})();